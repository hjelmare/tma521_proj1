% Make sure to run RunTask1 first, so that you have the right
% stuff in the workspace

% Settings
maxIterations = 50; % Max nr of attempts at rerouting colliding routes
viewTime = 0.2; % Time between plot updates (set to zero for max speed)

SolveTask2